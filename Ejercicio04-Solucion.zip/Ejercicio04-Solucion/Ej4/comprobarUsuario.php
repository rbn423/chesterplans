<?php
	if ($_REQUEST["user"] === "pablo") {
		echo "existe";
	} else {
		echo "disponible";
	}
?>