<?php
	require_once("includes/config.php");
	session_unset();
	header('Location: index.php');
?>