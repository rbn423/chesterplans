<div id="login">
		<form method="post" action="procesarLogin.php">
			<p>
				Username:
				<input type="text" name="nombre" size=15 />
			</p>
			<p>
				Password:
				<input type="password" name="contra" size=16 />
			</p>
			<div id="boton">
				<p>
					<input type="submit" value="Enviar">
					<input type="submit" value="Registrarse" formaction="registro.php">
				</p>
			</div>
		</form>
	</div>
	