<div id="pie">
	<p>Trabajo realizado por estudiantes del grado en informática de la Universidad Complutense de Madrid.<p>
	<p>Rubén Peña, Adrian Agudo, Arantxa Patricia Brock, Samuel Solo de Zaldívar</p>
</div>